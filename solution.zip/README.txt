# csf_assign02
Shayan Hossain (JHED: shossa11) & Saidaman Earla (JHED: searla1)

Please note:
1) We implemented the extra credit
2) Most of the work was done together, with very little emphasis on individual work. But for the purpose of this README, below are *estimations* of who mostly worked on what functionality. Whatever funcionality/functions are not mentioned below were evenly split among the team members (assembly functions, unit testing).

Saidaman Earla Contributions:
Prepared GitHub repo and mostly worked on the C main method.

Shayan Hossain Contributions:
Mostly worked on implementing C functions and did finishing touches (stylistic consistency, etc.).